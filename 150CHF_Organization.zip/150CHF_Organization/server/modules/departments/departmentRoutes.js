
/* =====================================================
   150CHF — DEPARTMENT BACKEND
   SECTION: DEPARTMENT ROUTES
   PostgreSQL-backed Department List API
   Search + Pagination + Organization/Company Names
   ===================================================== */

import { Router } from 'express';

export function createDepartmentRoutes(pool) {
  const router = Router();

  // =====================================================
  // SECTION 1: GET DEPARTMENT LIST
  // =====================================================

  router.get('/', async (req, res) => {
    try {

      // SECTION 1.1: SEARCH PARAMETERS

      const code = String(req.query.code ?? '').trim();
      const name = String(req.query.name ?? '').trim();
      const status = String(req.query.status ?? 'Select');

      // SECTION 1.2: PAGINATION PARAMETERS

      const page = Math.max(
        1,
        Number.parseInt(req.query.page, 10) || 1
      );

      const linesPerPage = Math.min(
        10000,
        Math.max(
          1,
          Number.parseInt(req.query.linesPerPage, 10) || 10
        )
      );

      const offset = (page - 1) * linesPerPage;

      // =====================================================
      // SECTION 2: BUILD DATABASE SEARCH FILTERS
      // =====================================================

      const filters = [];
      const values = [];

      if (code) {
        values.push(`%${code}%`);
        filters.push(
          `d.department_code ILIKE $${values.length}`
        );
      }

      if (name) {
        values.push(`%${name}%`);
        filters.push(
          `d.department_name ILIKE $${values.length}`
        );
      }

      if (status !== 'Select') {
        if (!['Active', 'Inactive'].includes(status)) {
          return res.status(400).json({
            message: 'Invalid Department status.'
          });
        }

        values.push(status);
        filters.push(
          `d.status = $${values.length}`
        );
      }

      const where = filters.length
        ? `WHERE ${filters.join(' AND ')}`
        : '';

      // =====================================================
      // SECTION 3: COUNT MATCHING DEPARTMENTS
      // =====================================================

      const countResult = await pool.query(
        `
          SELECT COUNT(*)::integer AS total
          FROM department d
          ${where}
        `,
        values
      );

      const total = countResult.rows[0].total;

      // =====================================================
      // SECTION 4: FETCH DEPARTMENTS FROM POSTGRESQL
      // =====================================================

      const result = await pool.query(
        `
          SELECT
            d.id,

            d.department_code AS code,
            d.department_name AS name,

            d.organization_id AS "organizationId",
            COALESCE(o.organization_name, '')
              AS "organizationName",

            d.company_id AS "companyId",
            COALESCE(c.company_name, '')
              AS "companyName",

            d.branch_id AS "branchId",
            d.department_type_id AS "departmentTypeId",

            d.dept_head_id AS "departmentHead",
            d.dept_head_email AS "headEmail",
            d.dept_head_contact AS "headPhone",

            d.description,
            d.status

          FROM department d

          LEFT JOIN organization o
            ON o.id = d.organization_id

          LEFT JOIN company c
            ON c.id = d.company_id
           AND c.organization_id = d.organization_id

          ${where}

          ORDER BY
            LOWER(d.department_code),
            LOWER(d.department_name),
            d.id

          LIMIT $${values.length + 1}
          OFFSET $${values.length + 2}
        `,
        [...values, linesPerPage, offset]
      );

      // =====================================================
      // SECTION 5: SEND PAGINATED RESPONSE
      // =====================================================

      res.json({
        rows: result.rows,
        total,
        page,
        linesPerPage,
        totalPages: Math.max(
          1,
          Math.ceil(total / linesPerPage)
        )
      });

    } catch (error) {
      console.error('Department GET error:', error);

      res.status(500).json({
        message: 'Unable to load departments.'
      });
    }
  });

  // =====================================================
  // SECTION 6: CREATE DEPARTMENT — POST API
  // =====================================================

  router.post('/', async (req, res) => {
    try {
      const {
        code,
        name,
        organizationId,
        companyId,
        branchId,
        departmentTypeId,
        departmentHead,
        headEmail,
        headPhone,
        description,
        status = 'Active'
      } = req.body ?? {};

      // SECTION 6.1: Required field validation
      if (
        !String(code ?? '').trim() ||
        !String(name ?? '').trim() ||
        !organizationId ||
        !companyId
      ) {
        return res.status(400).json({
          message:
            'Department Code, Name, Organization and Company are required.'
        });
      }

      if (!['Active', 'Inactive'].includes(status)) {
        return res.status(400).json({
          message: 'Invalid Department status.'
        });
      }

      // SECTION 6.2: Duplicate Department Code
      const duplicate = await pool.query(
        `SELECT id FROM department
         WHERE LOWER(department_code) = LOWER($1)
         LIMIT 1`,
        [String(code).trim()]
      );

      if (duplicate.rows.length) {
        return res.status(409).json({
          message: 'Department Code already exists.'
        });
      }

      // SECTION 6.3: Verify Organization/Company relationship
      const companyResult = await pool.query(
        `SELECT id FROM company
         WHERE id = $1 AND organization_id = $2`,
        [companyId, organizationId]
      );

      if (!companyResult.rows.length) {
        return res.status(400).json({
          message:
            'Selected Company does not belong to the selected Organization.'
        });
      }

      // SECTION 6.4: Insert into PostgreSQL
      const result = await pool.query(
        `
        INSERT INTO department (
          department_code,
          department_name,
          organization_id,
          company_id,
          branch_id,
          department_type_id,
          dept_head_id,
          dept_head_email,
          dept_head_contact,
          description,
          status
        )
        VALUES (
          $1, $2, $3, $4, $5, $6,
          $7, $8, $9, $10, $11
        )
        RETURNING id, department_code AS code,
                  department_name AS name, status
        `,
        [
          String(code).trim(),
          String(name).trim(),
          organizationId,
          companyId,
          branchId || null,
          departmentTypeId || null,
          departmentHead || null,
          headEmail || null,
          headPhone || null,
          description || null,
          status
        ]
      );

      return res.status(201).json(result.rows[0]);

    } catch (error) {
      console.error('Department POST error:', error);

      return res.status(500).json({
        message: 'Unable to create department.'
      });
    }
  });

  
  
  return router;
}
