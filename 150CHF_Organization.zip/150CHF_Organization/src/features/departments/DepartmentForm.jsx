
/* =====================================================
   150CHF — DEPARTMENT MODULE
   FILE: DepartmentForm.jsx

   Reuses existing MasterFormScreen.
   Supports Create / Edit / View / Copy navigation.
   ===================================================== */

import { Building2 } from 'lucide-react';

import { MasterFormScreen } from '../../components/master/MasterFormScreen';

import { emptyDepartment } from './departmentService';

export function DepartmentForm({
  mode = 'create',
  record = null,
  recordId = null,
  onCancel
}) {

  // =====================================================
  // SECTION 1: INITIAL DEPARTMENT DATA
  // =====================================================

  const form = {
    ...emptyDepartment,
    ...(record || {})
  };

  // =====================================================
  // SECTION 2: FORM MODE
  // =====================================================

  const formMode = mode === 'copy' ? 'create' : mode;

  // =====================================================
  // SECTION 3: FORM SUBMIT
  // Save integration will be added after form fields.
  // =====================================================

  const handleSubmit = (event) => {
    event?.preventDefault();
  };

  // =====================================================
  // SECTION 4: DEPARTMENT FORM UI
  // =====================================================

  return (
    <MasterFormScreen
      entity="Department"
      mode={formMode}
      record={form}
      onSubmit={handleSubmit}
      onCancel={onCancel}
      pending={false}
      errors={[]}
    >

      {/* SECTION 4.1: DEPARTMENT DETAILS */}

      <section className="reference-panel">

        <h2>
          <Building2 size={13} />
          Department Details
        </h2>

        {/* Department-specific fields will be added here */}

      </section>

    </MasterFormScreen>
  );
}
