
import { useState } from 'react';
import { OrganizationPage } from './features/organizations/OrganizationPage';

// SECTION 1: Department Module Import
import { DepartmentPage } from './features/departments/DepartmentPage';

export default function App() {
  const [activeModule, setActiveModule] = useState('organizations');

  // SECTION 2: Module Navigation
  return (
    <>
      <div style={{ display: 'flex', gap: '8px', padding: '8px' }}>
        <button
          type="button"
          onClick={() => setActiveModule('organizations')}
        >
          Organizations
        </button>

        <button
          type="button"
          onClick={() => setActiveModule('departments')}
        >
          Departments
        </button>
      </div>

      {/* SECTION 3: Render Selected Module */}
      {activeModule === 'organizations' && <OrganizationPage />}
      {activeModule === 'departments' && <DepartmentPage />}
    </>
  );
}
